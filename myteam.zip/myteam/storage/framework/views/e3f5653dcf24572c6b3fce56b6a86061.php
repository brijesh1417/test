<!doctype html>
<html class="no-js h-100" lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>My Team</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- css section-->
    <?php echo $__env->yieldContent('links'); ?>
    <!-- css section end-->
  </head>
  <body class="h-100">
   <?php echo $__env->yieldContent('body'); ?>
   <?php echo $__env->yieldContent('scripts'); ?>
  </body>
</html><?php /**PATH C:\xampp\htdocs\myteam\resources\views/admin/layouts/master.blade.php ENDPATH**/ ?>