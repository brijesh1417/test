

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="layoutSidenav">
    <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
                <h1 class="mt-4">Player</h1>


                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-table me-1"></i>
                        Add Player
                        <a href="<?php echo e(route('admin.player.list')); ?>" class="btn btn-primary float-end">
                            << Back</a>
                    </div>
                    <div class="card-body">
                        <?php if(Session::has('message')): ?>
                        <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
                            
                            <i class="fa fa-check mx-2"></i>
                            <strong><?php echo e(Session::get('message')); ?></strong>
                        </div>
                        <?php endif; ?>

                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <strong>Whoops!</strong> There were some problems with your input.
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>


                        <form method="post" action="<?php echo e(route('admin.player.create')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3 mt-3">
                                <label for="team" class="form-label">Select Team:</label>
                                <select class="form-control" name="team" id="team">
                                    <option value="">--select--</option>
                                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3 mt-3">
                                <label for="first_name" class="form-label">First Name:</label>
                                <input type="text" class="form-control" id="first_name" name="first_name" placeholder="Enter first name">
                            </div>
                            <div class="mb-3 mt-3">
                                <label for="last_name" class="form-label">Last Name:</label>
                                <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Enter last name">
                            </div>
                            <div class="mb-3 mt-3">
                                <label for="jersey_number" class="form-label">Jersey Number:</label>
                                <input type="text" class="form-control" id="jersey_number" name="jersey_number" placeholder="Enter jersey number">
                            </div>
                            <div class="mb-3 mt-3">
                                <label for="country" class="form-label">Country:</label>
                                <input type="text" class="form-control" id="country" name="country" placeholder="Enter country">
                            </div>

                            <div class="mb-3 mt-3">
                                <label for="matches" class="form-label">Matches:</label>
                                <input type="text" class="form-control" id="matches" name="matches" placeholder="Enter matches">
                            </div>

                            <div class="mb-3 mt-3">
                                <label for="total_run" class="form-label">Total Run:</label>
                                <input type="text" class="form-control" id="total_run" name="total_run" placeholder="Enter total run">
                            </div>

                            <div class="mb-3 mt-3">
                                <label for="highest_scores" class="form-label">Highest Scores:</label>
                                <input type="text" class="form-control" id="highest_scores" name="highest_scores" placeholder="Enter highest scores">
                            </div>

                            <div class="mb-3 mt-3">
                                <label for="fifties" class="form-label">Fifties:</label>
                                <input type="text" class="form-control" id="fifties" name="fifties" placeholder="Enter fifties">
                            </div>

                            <div class="mb-3 mt-3">
                                <label for="hundreds" class="form-label">Hundreds:</label>
                                <input type="text" class="form-control" id="hundreds" name="hundreds" placeholder="Enter hundreds">
                            </div>
                            
                            <div class="mb-3">
                                <label for="image" class="form-label">Player Image:</label>
                                <input type="file" class="form-control" id="image" name="image">
                            </div>

                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </main>
        <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myteam\resources\views/admin/player/create.blade.php ENDPATH**/ ?>