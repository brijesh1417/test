

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="layoutSidenav">
    <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
                <h1 class="mt-4">Team</h1>


                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-table me-1"></i>
                        Team List
                        <a href="<?php echo e(route('admin.team.create')); ?>" class="btn btn-primary float-end">Add Team</a>
                    </div>
                    <div class="card-body">
                        <table id="datatablesSimple">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Logo</th>
                                    <th>Name</th>
                                    <th>Club State</th>
                                    <th>Action</th>

                                </tr>
                            </thead>
                            
                            <tbody>

                                <?php $i = 1 ?>
                      <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo $i; ?></td>
                          <td> <img style="width: 50px;" src="<?php echo e(asset('images/'.$team->logo)); ?>" alt=""></td>
                          <td> <a href="<?php echo e(route('admin.team.player_list',$team->id)); ?>">
                          <?php echo $team->name; ?> </a> </td>
                          <td><?php echo $team->state_title; ?></td>
                          
                          <td>
                          <div class="btn-group btn-group-sm">


                              <button type="button" class="btn btn-primary">
                              <a href="<?php echo e(route('admin.team.edit',$team->id)); ?>" class="text-white">
                               Edit </a>
                              </button>
                            <button type="button" class="btn btn-danger">
                            <a class="text-white" href="<?php echo e(route('admin.team.delete',$team->id)); ?>" onclick="return confirm('Are you sure want to delete?');">
                              Delete </a>
                            </button>
                            
                          </div>
                          </td>
                        </tr>
                        <?php $i++ ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
        <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myteam\resources\views/admin/team/list.blade.php ENDPATH**/ ?>