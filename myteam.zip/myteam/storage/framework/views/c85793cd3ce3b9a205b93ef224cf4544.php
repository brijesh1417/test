<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <div class="sb-sidenav-menu-heading">Core</div>
                <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
                
                <a class="nav-link" href="<?php echo e(route('admin.team.list')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                    Team
                </a>
                <a class="nav-link" href="<?php echo e(route('admin.player.list')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Player
                </a>
                <a class="nav-link" href="<?php echo e(route('admin.matche.list')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Matches
                </a>
                <a class="nav-link" href="<?php echo e(route('admin.point.list')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Points
                </a>
            </div>
        </div>
        
    </nav>
</div><?php /**PATH C:\xampp\htdocs\myteam\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>