

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="layoutSidenav">
    <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
                <h1 class="mt-4">Point</h1>


                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-table me-1"></i>
                        Point List
                        
                    </div>
                    <div class="card-body">
                        <table id="datatablesSimple">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Logo</th>
                                    <th>Team Name</th>
                                    <th>Total Matche</th>
                                    <th>Total Win</th>
                                    <th>Total Lose</th>
                                    <th>Total Point</th>
                                    
                                </tr>
                            </thead>
                            
                            <tbody>

                      <?php $i = 1 ?>
                      <?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo $i; ?></td>
                          <td> <img style="width: 50px;" src="<?php echo e(asset('images/'.$list->team_logo)); ?>" alt=""></td>
                          <td><?php echo $list->team_name; ?></td>
                          <td><?php echo $list->total_matche; ?></td>
                          <td><?php echo $list->total_win; ?></td>
                          <td><?php echo $list->total_lose; ?></td>
                          <td><?php echo $list->total_point; ?></td>
                          
                          
                        </tr>
                        <?php $i++ ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
        <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myteam\resources\views/admin/point/list.blade.php ENDPATH**/ ?>