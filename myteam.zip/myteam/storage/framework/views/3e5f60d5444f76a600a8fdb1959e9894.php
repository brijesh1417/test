

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="layoutSidenav">
    <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
                <h1 class="mt-4">Matche</h1>


                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-table me-1"></i>
                       Update Matche Winner
                        <a href="<?php echo e(route('admin.matche.list')); ?>" class="btn btn-primary float-end">
                            << Back</a>
                    </div>
                    <div class="card-body">
                        <?php if(Session::has('message')): ?>
                        <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
                            
                            <i class="fa fa-check mx-2"></i>
                            <strong><?php echo e(Session::get('message')); ?></strong>
                        </div>
                        <?php endif; ?>

                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <strong>Whoops!</strong> There were some problems with your input.
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>


                        <form method="post" action="<?php echo e(route('admin.matche.update_winner',$matche->id)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3 mt-3">
                                <label for="team_1" class="form-label">Select Matche Status:</label>
                                <select class="form-control" name="matche_status" id="matche_status">
                                    <option value="">--select--</option>
                                   
                                    <option value="1">No Result</option>
                                    <option value="2">Tie</option>
                                    <option value="3">Win</option>
                                    
                                </select>
                            </div>

                            <div class="mb-3 mt-3 winner-list d-none">
                                <label for="team_1" class="form-label">Select Winner:</label>
                                <select class="form-control" name="winner" id="winner">
                                    <option value="">--select--</option>
                                   
                                    <option value="<?php echo e($team_name[0]->team_1); ?>"><?php echo e($team_name[0]->team_name1); ?></option>
                                    <option value="<?php echo e($team_name[0]->team_2); ?>"><?php echo e($team_name[0]->team_name2); ?></option>
                                    
                                </select>
                            </div>
             
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </main>
        <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myteam\resources\views/admin/matche/update_winner.blade.php ENDPATH**/ ?>