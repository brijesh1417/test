

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="layoutSidenav">
    <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
                <h1 class="mt-4">Matche</h1>


                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-table me-1"></i>
                        Add Matche
                        <a href="<?php echo e(route('admin.matche.list')); ?>" class="btn btn-primary float-end">
                            << Back</a>
                    </div>
                    <div class="card-body">
                        <?php if(Session::has('message')): ?>
                        <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
                            
                            <i class="fa fa-check mx-2"></i>
                            <strong><?php echo e(Session::get('message')); ?></strong>
                        </div>
                        <?php endif; ?>

                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <strong>Whoops!</strong> There were some problems with your input.
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>


                        <form method="post" action="<?php echo e(route('admin.matche.create')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3 mt-3">
                                <label for="team_1" class="form-label">Select Team 1:</label>
                                <select class="form-control" name="team_1" id="team_1">
                                    <option value="">--select--</option>
                                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="mb-3 mt-3">
                                <label for="team_2" class="form-label">Select Team 2:</label>
                                <select class="form-control" name="team_2" id="team_2">
                                    <option value="">--select--</option>
                                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="mb-3 mt-3">
                                <label for="matche_date" class="form-label">Select Date:</label>
                                <input type="text" class="form-control" id="matche_date" name="matche_date" >
                            </div>

                            <div class="mb-3 mt-3">
                                <label for="matche_time" class="form-label">Select Time:</label>
                                <input type="text" class="form-control" id="matche_time" name="matche_time" >
                            </div>
                            

                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </main>
        <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myteam\resources\views/admin/matche/create.blade.php ENDPATH**/ ?>