<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Reader\Exception;
use PhpOffice\PhpSpreadsheet\Writer\Xls;
use PhpOffice\PhpSpreadsheet\IOFactory;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('upload-csv-data');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {
        $this->validate($request, [
            'upload_csv' => 'required|file|mimes:xls,xlsx'
        ]);
        $the_file = $request->file('upload_csv');
        try{
            $spreadsheet = IOFactory::load($the_file->getRealPath());
            $sheet        = $spreadsheet->getActiveSheet();
            $row_limit    = $sheet->getHighestDataRow();
            $column_limit = $sheet->getHighestDataColumn();
            $row_range    = range( 2, $row_limit );
            $column_range = range( 'F', $column_limit );
            $startcount = 2;
            $data = array();
            foreach ( $row_range as $row ) {
                $data[] = [
                    'employee_id' =>$sheet->getCell( 'A' . $row )->getValue(),
                    'full_name' => $sheet->getCell( 'B' . $row )->getValue(),
                    'job_title' => $sheet->getCell( 'C' . $row )->getValue(),
                    'department' => $sheet->getCell( 'D' . $row )->getValue(),
                    'business_unit' => $sheet->getCell( 'E' . $row )->getValue(),
                    'gender' =>$sheet->getCell( 'F' . $row )->getValue(),
                    'ethnicity' =>$sheet->getCell( 'G' . $row )->getValue(),
                    'age' =>$sheet->getCell( 'H' . $row )->getValue(),
                    'hire_date' =>$sheet->getCell( 'I' . $row )->getValue(),
                    'annual_salary' =>$sheet->getCell( 'J' . $row )->getValue(),
                    'bonus' =>$sheet->getCell( 'K' . $row )->getValue(),
                    'country' =>$sheet->getCell( 'L' . $row )->getValue(),
                    'city' =>$sheet->getCell( 'M' . $row )->getValue(),
                    'exit_date' =>$sheet->getCell( 'N' . $row )->getValue(),
                ];
                $startcount++;
            }

           // dd($data);
           DB::table('employees')->insert($data);
        }
        catch (Exception $e) {
                $error_code = $e->errorInfo[1];
                return back()->withErrors('There was a problem uploading the data!');
        }

            
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
