<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Employee;

class ApiController extends Controller
{
    public function index(Request $request)
    {
       
        $search = $request->search;
        $job_title = $request->job_title;
        $department = $request->department;
        $gender = $request->gender;
        $country = $request->country;
        $city = $request->city;
        $from_hiring_date = $request->from_hiring_date;
        $to_hiring_date = $request->to_hiring_date;
        $sort_by = $request->sort_by;

        $search_query = [];
        if($search!=''){
            $search_query['employee_id']=$search;
        }
        if($job_title!=''){
            $search_query['job_title']=$job_title;
        }
        if($department!=''){
            $search_query['department']=$job_title;
        }
        if($gender!=''){
            $search_query['gender']=$gender;
        }
        if($country!=''){
            $search_query['country']=$country;
        }
        if($city!=''){
            $search_query['city']=$city;
        }
        $from_date = '';
        $to_date = '';
        if($from_hiring_date!=''){
            $from_date=$from_hiring_date;
        }
        if($to_hiring_date!=''){
            $to_date=$to_hiring_date;
        }
        $order = 'id';
        if($sort_by!=''){
            $order = 'hire_date';
        }

        $employee = Employee::
        where($search_query)
        //->whereBetween('hire_date', [$from_date,$to_date])
        ->orderBy($order,'desc')
        ->get();
        

        return response()->json([
            'status' => 'success',
            'data' => $employee,
        ]);
    }
}
